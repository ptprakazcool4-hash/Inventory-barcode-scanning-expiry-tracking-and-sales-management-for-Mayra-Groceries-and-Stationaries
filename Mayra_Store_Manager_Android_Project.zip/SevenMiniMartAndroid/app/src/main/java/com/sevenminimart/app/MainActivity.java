package com.sevenminimart.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

public class MainActivity extends Activity {
    private WebView webView;
    private ActivityResultLauncher<ScanOptions> barcodeLauncher;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        barcodeLauncher = registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) {
                String code = result.getContents().replace("\\", "\\\\").replace("'", "\\'");
                webView.evaluateJavascript(
                    "document.getElementById('manualBarcode').value='" + code + "';" +
                    "if(typeof lookup==='function'){lookup('" + code + "');}" +
                    "document.getElementById('sBarcode').value='" + code + "';" +
                    "var p=typeof findProduct==='function'?findProduct('" + code + "'):null;" +
                    "if(p){document.getElementById('sProduct').value=p.id;document.getElementById('sPrice').value=p.price;}",
                    null
                );
            }
        });

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void scanBarcode() {
                runOnUiThread(() -> {
                    ScanOptions options = new ScanOptions();
                    options.setPrompt("Point camera at product barcode");
                    options.setBeepEnabled(false);
                    options.setOrientationLocked(false);
                    options.setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES);
                    barcodeLauncher.launch(options);
                });
            }
        }, "AndroidScanner");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
