# Mayra Store Manager Android project

This is an Android Studio project wrapping the Mayra Store Manager inventory prototype in a native Android WebView. It includes a native ZXing camera barcode scanner.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`MayraStoreManager`) in Android Studio.
3. Allow Gradle sync to finish (internet is required the first time to download Android Gradle Plugin and libraries).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- The app stores inventory data locally in the app/browser storage on that device. Export backups regularly.
- Product lookups use the Open Food Facts API when internet is available. Product data, images, and MRP may be missing or inaccurate; verify packaging and enter MRP/expiry manually.
- This is a starter app, not yet a tax-compliant POS or cloud-synchronised multi-device system.
- The source project is provided; a compiled APK is not included because this environment does not have the Android SDK/Gradle build environment installed.
